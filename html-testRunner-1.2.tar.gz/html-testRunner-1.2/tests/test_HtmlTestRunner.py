#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_HtmlTestRunner
----------------------------------

Tests for `HtmlTestRunner` module.
"""


import sys
import unittest

import HtmlTestRunner



class TestHtmltestrunner(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000_something(self):
        pass
