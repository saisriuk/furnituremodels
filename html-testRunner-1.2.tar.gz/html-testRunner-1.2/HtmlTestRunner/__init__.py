# -*- coding: utf-8 -*-
from .runner import HTMLTestRunner


__author__ = """Ordanis Sanchez Suero"""
__email__ = 'ordanisanchez@gmail.com'
__version__ = '1.2'
